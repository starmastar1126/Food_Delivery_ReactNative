'use strict';

import React, from 'react';

import _ from 'underscore';

default export class Cart {
	constructor(props) {
	  super(props);
	
	  this.state = {
	  	items : [
	  	]
	  };
	}
}